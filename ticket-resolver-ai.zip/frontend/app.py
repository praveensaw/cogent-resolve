import streamlit as st
import requests

BACKEND_URL = "http://127.0.0.1:5000"

st.set_page_config(page_title="Ticket Resolver AI", layout="wide")

st.title("🎫 Ticket Resolver AI")

# Sidebar mode
st.sidebar.header("Settings")
mode = st.sidebar.radio("Choose Mode", ["Ask LLM", "Find Similar Tickets"])

# Ticket submission form
st.subheader("📝 Enter Ticket Details")

ticket_title = st.text_input("Ticket Title")
ticket_description = st.text_area("Ticket Description", height=150)

ticket_topic = st.selectbox(
    "Ticket Topic",
    ["Database", "Networking", "Application Error", "Performance", "Security", "Access rights", "Other"]
)

ticket_type = st.selectbox(
    "Ticket Type",
    ["Incident", "Service Request", "Problem", "Change Request"]
)

if st.button("Apply"):
    if not ticket_title.strip() or not ticket_description.strip():
        st.warning("⚠️ Please fill in both Title and Description.")
    else:
        ticket_payload = f"""
        Title: {ticket_title}
        Description: {ticket_description}
        Topic: {ticket_topic}
        Type: {ticket_type}
        """.strip()

        if mode == "Ask LLM":
            with st.spinner("💭 Analyzing with Gemini..."):
                response = requests.post(f"{BACKEND_URL}/query", json={"query": ticket_payload})
                if response.status_code == 200:
                    result = response.json()
                    st.subheader("🧠 Suggested Resolution")
                    st.success(result.get("suggestion", "No suggestion returned"))
                    st.subheader("📌 Relevant Past Tickets")
                    for ctx in result.get("context", []):
                        with st.expander(f"Ticket {ctx.get('ticket_id','N/A')}"):
                            st.write(f"**Title:** {ctx.get('title','N/A')}")
                            st.write(f"**Description:** {ctx.get('ticket_description','N/A')}")
                            st.write(f"**Resolution:** {ctx.get('resolution_summary','N/A')}")

                    # Feedback buttons
                    st.subheader("📝 Was this answer helpful?")
                    col1, col2, col3 = st.columns(3)
                    if col1.button("👍 Excellent"):
                        requests.post(f"{BACKEND_URL}/feedback", json={"ticket_payload": ticket_payload, "ai_answer": result.get("suggestion"), "rating": "Excellent"})
                        st.success("Feedback saved!")
                    if col2.button("🙂 Good"):
                        requests.post(f"{BACKEND_URL}/feedback", json={"ticket_payload": ticket_payload, "ai_answer": result.get("suggestion"), "rating": "Good"})
                        st.success("Feedback saved!")
                    if col3.button("👎 Poor"):
                        requests.post(f"{BACKEND_URL}/feedback", json={"ticket_payload": ticket_payload, "ai_answer": result.get("suggestion"), "rating": "Poor"})
                        st.success("Feedback saved!")

        elif mode == "Find Similar Tickets":
            with st.spinner("🔍 Retrieving similar tickets..."):
                response = requests.post(f"{BACKEND_URL}/similar", json={"query": ticket_payload})
                if response.status_code == 200:
                    results = response.json()
                    st.subheader("📌 Top Similar Tickets")
                    for ctx in results:
                        with st.expander(f"Ticket {ctx.get('ticket_id','N/A')}"):
                            st.write(f"**Title:** {ctx.get('title','N/A')}")
                            st.write(f"**Description:** {ctx.get('ticket_description','N/A')}")
                            st.write(f"**Resolution:** {ctx.get('resolution_summary','N/A')}")
                else:
                    st.error(f"Error: {response.text}")
