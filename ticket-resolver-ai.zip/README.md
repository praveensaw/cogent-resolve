# Ticket Resolver AI

### Setup Instructions

1. Clone this project or unzip it.
2. Install backend dependencies:
   ```bash
   cd backend
   pip install -r requirements.txt
   ```
3. Install frontend dependencies:
   ```bash
   cd ../frontend
   pip install -r requirements.txt
   ```
4. Run backend:
   ```bash
   python app.py
   ```
5. Run frontend:
   ```bash
   streamlit run app.py
   ```

### Notes
- Place your Gemini API key in environment:
  ```bash
  export GEMINI_API_KEY="your_api_key_here"
  ```
