import os

# Google Gemini API Key (set in environment variable for safety)
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "YOUR_GEMINI_KEY")

# File paths
DATASET_PATH = "backend/data/expanded_tickets_700.csv"
FAISS_INDEX_PATH = "backend/data/faiss_index.idx"
FAISS_META_PATH = "backend/data/faiss_meta.parquet"
FEEDBACK_PATH = "backend/data/feedback_ratings.csv"
