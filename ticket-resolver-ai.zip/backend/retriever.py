import faiss
import pandas as pd
import numpy as np
from langchain_huggingface import HuggingFaceEmbeddings
from backend.config import FAISS_INDEX_PATH, FAISS_META_PATH

class Retriever:
    def __init__(self):
        self.index = faiss.read_index(FAISS_INDEX_PATH)
        self.df = pd.read_parquet(FAISS_META_PATH)
        self.embedder = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

    def search(self, query: str, top_k=5):
        query_emb = self.embedder.embed_query(query)
        query_emb = np.array(query_emb).astype("float32").reshape(1, -1)
        D, I = self.index.search(query_emb, top_k)
        return self.df.iloc[I[0]].to_dict(orient="records")
