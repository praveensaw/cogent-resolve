from flask import Flask, request, jsonify
from backend.retriever import Retriever
from backend.utils import save_feedback
from backend.config import GEMINI_API_KEY
import google.generativeai as genai

app = Flask(__name__)
retriever = Retriever()

# Configure Gemini
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel("gemini-2.0-flash")

@app.route("/query", methods=["POST"])
def query():
    data = request.json
    query = data.get("query", "")

    # Retrieve similar tickets
    context = retriever.search(query, top_k=5)

    # Call Gemini for suggestion
    response = model.generate_content(query)
    suggestion = response.text if response else "No response generated."

    return jsonify({"suggestion": suggestion, "context": context})

@app.route("/similar", methods=["POST"])
def similar():
    data = request.json
    query = data.get("query", "")
    results = retriever.search(query, top_k=5)
    return jsonify(results)

@app.route("/feedback", methods=["POST"])
def feedback():
    data = request.json
    ticket_payload = data.get("ticket_payload", "")
    ai_answer = data.get("ai_answer", "")
    rating = data.get("rating", "Unrated")

    save_feedback(ticket_payload, ai_answer, rating)
    return jsonify({"status": "success", "message": "Feedback saved."})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
