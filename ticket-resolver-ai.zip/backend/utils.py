import pandas as pd
import os
from backend.config import FEEDBACK_PATH

def save_feedback(ticket_payload, ai_answer, rating):
    feedback = {
        "ticket_payload": ticket_payload,
        "ai_answer": ai_answer,
        "rating": rating
    }

    if os.path.exists(FEEDBACK_PATH):
        df = pd.read_csv(FEEDBACK_PATH)
        df = pd.concat([df, pd.DataFrame([feedback])], ignore_index=True)
    else:
        df = pd.DataFrame([feedback])

    df.to_csv(FEEDBACK_PATH, index=False)
